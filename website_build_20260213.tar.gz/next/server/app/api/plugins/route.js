var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/plugins/route.js")
R.c("server/chunks/[root-of-the-server]__0d77a39c._.js")
R.c("server/chunks/[root-of-the-server]__7040479c._.js")
R.c("server/chunks/[root-of-the-server]__5f61309d._.js")
R.c("server/chunks/68d47_amp-spot_website__next-internal_server_app_api_plugins_route_actions_92739f4b.js")
R.m(46871)
module.exports=R.m(46871).exports
