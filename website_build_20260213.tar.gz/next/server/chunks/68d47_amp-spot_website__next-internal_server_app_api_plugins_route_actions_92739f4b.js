module.exports=[45980,(e,o,d)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_api_plugins_route_actions_92739f4b.js.map