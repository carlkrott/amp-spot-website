module.exports=[89849,(e,o,d)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_favicon_ico_route_actions_1ba10ea7.js.map