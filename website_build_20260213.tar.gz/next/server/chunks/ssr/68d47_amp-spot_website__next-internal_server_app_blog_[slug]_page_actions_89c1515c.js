module.exports=[3918,(a,b,c)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_blog_%5Bslug%5D_page_actions_89c1515c.js.map