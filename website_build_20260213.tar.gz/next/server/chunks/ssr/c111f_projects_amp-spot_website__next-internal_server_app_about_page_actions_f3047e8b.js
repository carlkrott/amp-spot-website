module.exports=[11506,(a,b,c)=>{}];

//# sourceMappingURL=c111f_projects_amp-spot_website__next-internal_server_app_about_page_actions_f3047e8b.js.map