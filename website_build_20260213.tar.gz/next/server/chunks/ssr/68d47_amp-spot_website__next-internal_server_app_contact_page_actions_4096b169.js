module.exports=[13115,(a,b,c)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_contact_page_actions_4096b169.js.map