module.exports=[18205,(a,b,c)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_pricing_page_actions_732a0b22.js.map