(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,68855,86252,5267,e=>{"use strict";e.i(97786),e.i(48370),e.i(29263);var t=e.i(47544),s=e.i(29505);function o({plugin:e}){return(0,t.jsxs)(s.default,{href:`/plugins/${e.slug}`,className:"group relative overflow-hidden rounded-2xl bg-slate-800/50 p-6 backdrop-blur-sm transition-all hover:bg-slate-800/70 hover:shadow-xl hover:shadow-purple-500/10",children:[(0,t.jsx)("div",{className:"absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 transition-opacity group-hover:opacity-100"}),(0,t.jsxs)("div",{className:"relative",children:[2===e.phase&&(0,t.jsx)("span",{className:"mb-3 inline-flex items-center rounded-full bg-amber-500/20 px-3 py-1 text-xs font-medium text-amber-400",children:"Coming Soon"}),(0,t.jsx)("h3",{className:"text-xl font-bold text-white group-hover:text-purple-300 transition-colors",children:e.title}),(0,t.jsx)("p",{className:"mt-2 text-sm font-medium text-purple-400",children:e.tagline}),(0,t.jsx)("p",{className:"mt-4 text-gray-400 line-clamp-3",children:e.description}),(0,t.jsxs)("div",{className:"mt-6 flex items-center text-sm font-medium text-purple-400 group-hover:text-purple-300",children:["Learn more",(0,t.jsx)("svg",{className:"ml-2 h-4 w-4 transition-transform group-hover:translate-x-1",fill:"none",viewBox:"0 0 24 24",strokeWidth:"2",stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"})})]})]})]})}function i({plugins:e,title:s,subtitle:i}){return(0,t.jsx)("section",{id:"plugins",className:"bg-slate-900 py-24 sm:py-32",children:(0,t.jsxs)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:[(s||i)&&(0,t.jsxs)("div",{className:"mx-auto max-w-2xl text-center mb-16",children:[s&&(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white sm:text-4xl",children:s}),i&&(0,t.jsx)("p",{className:"mt-4 text-lg text-gray-400",children:i})]}),(0,t.jsx)("div",{className:"grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3",children:e.map(e=>(0,t.jsx)(o,{plugin:e},e.slug))})]})})}e.s(["PluginGrid",()=>i],86252);let a=[{slug:"how-to-fix-muddy-mixes-eq-tutorial",title:"How to Fix Muddy Mixes with EQ (Video Tutorial)",excerpt:"Watch our step-by-step video guide on eliminating mud from your mixes using surgical EQ techniques. Learn exactly where to cut and how much.",content:`
# How to Fix Muddy Mixes with EQ

Muddy mixes are one of the most common problems in music production. In this video tutorial, we show you exactly how to identify and remove mud using EQ.

## Watch the Full Tutorial

<div class="aspect-video w-full bg-slate-800 rounded-xl flex items-center justify-center">
  <a href="https://youtube.com/@ampspot" target="_blank" class="text-orange-500">Watch on YouTube</a>
</div>

## Key Takeaways

### 1. Identify the Problem Frequencies
- **200-400Hz** is where most mud lives
- Use a sweeping technique to find the exact frequency
- Boost first to find, then cut to fix

### 2. Use Subtractive EQ
- Start with gentle cuts (2-4dB)
- Use moderate Q values (1-3) for natural sound
- Don't overdo it—subtle changes add up

### 3. Check in Context
- Always EQ while listening to the full mix
- Solo can be misleading
- Toggle your EQ on/off to verify improvement

### 4. Address Multiple Instruments
- Mud often comes from frequency buildup
- EQ several instruments slightly instead of one drastically
- Create separation between similar instruments

## Tools Used in This Video

We used the [Amp Spot EQ Plugin](/plugins/eq) for all demonstrations in this video. It's free to try for 14 days.

## What's Next?

Want more mixing tutorials? Subscribe to our [YouTube channel](https://youtube.com/@ampspot) and check out our [blog](/blog) for written guides.

---

*Video published February 10, 2024 • Runtime: 12:34*
`,author:"Amp Spot Team",publishedAt:"2024-02-10",tags:["Video","Tutorial","Mixing","EQ"],readTime:4},{slug:"compression-for-beginners-masterclass",title:"Compression Masterclass for Beginners (Full Video)",excerpt:"Everything you need to know about compression in one comprehensive video tutorial. From basic concepts to advanced techniques.",content:`
# Compression Masterclass for Beginners

Compression can be intimidating for beginners, but it doesn't have to be. This video breaks down everything you need to know in simple, easy-to-understand terms.

## Watch the Full Masterclass

<div class="aspect-video w-full bg-slate-800 rounded-xl flex items-center justify-center">
  <a href="https://youtube.com/@ampspot" target="_blank" class="text-orange-500">Watch on YouTube</a>
</div>

## Topics Covered

### Part 1: Understanding Compression (0:00-8:45)
- What compression does to audio
- Why we use it in mixing and mastering
- Common misconceptions

### Part 2: The Four Main Controls (8:46-18:20)
- **Threshold**: When compression starts
- **Ratio**: How much compression applies
- **Attack**: How fast compression engages
- **Release**: How fast compression lets go

### Part 3: Practical Applications (18:21-32:15)
- Compressing vocals for consistency
- Drums: punch vs. sustain
- Bass: glue and control
- Master bus compression

### Part 4: Common Mistakes (32:16-42:00)
- Over-compressing (and how to avoid it)
- Wrong attack/release times
- Not using your ears
- Forgetting makeup gain

## Download the Session Files

Patreon supporters get access to the full session files used in this tutorial. [Join here](https://patreon.com/ampspot).

## Plugin Used

We used the [Amp Spot Compressor](/plugins/compressor) exclusively for this masterclass. Try it free for 14 days.

---

*Video published February 8, 2024 • Runtime: 42:18*
`,author:"Amp Spot Team",publishedAt:"2024-02-08",tags:["Video","Tutorial","Compression","Mixing"],readTime:6},{slug:"amp-spot-eq-plugin-walkthrough",title:"Amp Spot EQ Plugin - Complete Feature Walkthrough",excerpt:"Discover every feature of our flagship EQ plugin in this detailed walkthrough video. Learn tips, tricks, and hidden features.",content:`
# Amp Spot EQ Plugin - Complete Walkthrough

Get to know every feature, button, and workflow tip for the Amp Spot EQ plugin in this comprehensive video guide.

## Watch the Walkthrough

<div class="aspect-video w-full bg-slate-800 rounded-xl flex items-center justify-center">
  <a href="https://youtube.com/@ampspot" target="_blank" class="text-orange-500">Watch on YouTube</a>
</div>

## Features Covered

### The Interface (0:00-5:30)
- Main display and spectrum analyzer
- Band controls and frequency selection
- Preset management

### EQ Bands Explained (5:31-15:45)
- High-pass and low-pass filters
- Parametric bands (gain, frequency, Q)
- Shelving bands
- Mid/Side processing mode

### Advanced Features (15:46-25:20)
- Spectrum analyzer overlays
- A/B comparison mode
- Undo/redo functionality
- Preset browser and favorites

### Workflow Tips (25:21-32:50)
- Keyboard shortcuts
- Quick band copying
- Saving custom presets
- Integration with your DAW

### Sound Quality & Performance (32:51-38:00)
- Zero-latency design
- CPU usage optimization
- Oversampling options
- Analog modeling (coming in v2.0)

## Hidden Features

Did you know you can:
- **Double-click** a band to solo it
- **Option/Alt + drag** to adjust Q while moving frequency
- **Shift + click** to reset a parameter to default
- **Right-click** anywhere to access quick menu

## Download & Try

The EQ plugin is available now with a free 14-day trial. [Download here](/download).

---

*Video published February 5, 2024 • Runtime: 38:42*
`,author:"Amp Spot Team",publishedAt:"2024-02-05",tags:["Video","Product","EQ","Tutorial"],readTime:5},{slug:"introducing-amp-spot",title:"Introducing Amp Spot: Pro Audio Tools for Everyone",excerpt:"Professional audio plugins shouldn't cost a fortune. We're changing that with our suite of powerful, accessible tools for music producers of all levels.",content:`
# Introducing Amp Spot: Pro Audio Tools for Everyone

When we started Amp Spot, we had a simple mission: make professional-grade audio tools accessible to everyone, regardless of budget or experience level.

## The Problem

The audio plugin world has a problem. High-end plugins cost hundreds of dollars each, putting them out of reach for bedroom producers, students, and hobbyists. Free plugins often lack the polish and features that pros need.

We believed there had to be a middle ground.

## Our Solution

Amp Spot brings you professional-quality plugins at prices that make sense. Each plugin in our suite is designed with:

- **Transparent Algorithms**: No hidden processing, just clean audio path
- **Intuitive Interfaces**: Learn in minutes, master in hours
- **CPU-Friendly Design**: Run more instances, stay creative longer
- **Comprehensive Documentation**: Learn the why behind the what

## What's Available Now

Our Phase 1 launch includes essential mixing tools:

- **Equalizer**: Precision EQ with analog-modeled curves
- **Compressor**: Versatile dynamics control with multiple character modes
- **Analyzer**: Real-time spectrum, frequency, and correlation analysis
- **Saturation**: Harmonic richness with multiple saturation types
- **Transient Shaper**: Punch up or tame your attacks and sustain

## What's Next

We're already working on Phase 2, with more specialized tools including limiting, de-essing, and creative effects. Follow our blog for updates and tutorials.

## Try for Free

The best way to understand our approach? Try it yourself. All plugins come with a 14-day free trial—no credit card required.

[Download Now](/download)

---

*Have questions? Check our [FAQ](/faq) or [contact support](/support).*
`,author:"Amp Spot Team",publishedAt:"2024-01-15",tags:["Announcement","Product"],readTime:3},{slug:"mid-side-processing",title:"Understanding Mid/Side Processing",excerpt:"Mid/Side processing is a powerful technique for mixing and mastering. Learn how it works, when to use it, and how it can transform your stereo image.",content:`
# Understanding Mid/Side Processing

Mid/Side (M/S) processing is one of those techniques that sounds intimidating but offers powerful creative possibilities once you understand it. Let's break it down.

## What is Mid/Side?

Traditional stereo audio has two channels: Left and Right. Mid/Side processing reorganizes this information differently:

- **Mid (Mono)**: Everything that's the same in both speakers (center-panned elements)
- **Side (Stereo)**: Everything that's different between speakers (width, reverb, stereo effects)

Mathematically:
- Mid = Left + Right
- Side = Left - Right

## Why Use M/S Processing?

M/S processing opens up several possibilities:

### 1. EQ the Center and Sides Separately
Brighten vocals without harsh cymbals. Add clarity to your bass without affecting the stereo width.

### 2. Control Stereo Width
Boost the Side channel for wider mixes. Reduce it for focused, mono-compatible tracks.

### 3. Compression Strategies
Compress the Mid differently than the Sides—gentle on the sides for preserving space, harder on the mid for glue and punch.

### 4. Saturation Tricks
Add warmth to your center elements without making the whole track muddy.

## Practical Applications

### Vocal Processing
Apply brighter EQ only to the Mid channel where vocals live. Your vocals cut through without making cymbals harsh.

### Reverb Control
Reverb typically lives in the Side channel. You can EQ or saturate it independently to clean up muddy mixes.

### Low-End Management
Bass and kick should be mono. Use M/S EQ to ensure all low-frequency energy is in the Mid channel.

## Common Pitfalls

**Don't overdo it:** Subtle M/S processing is powerful. Heavy-handed M/S manipulation can cause phase issues and mono incompatibility.

**Check mono regularly:** Always test your mixes in mono. Excessive Side processing can collapse poorly.

**Trust your ears:** M/S analysis is cool, but if it sounds wrong, it is wrong.

## Try M/S Processing

Our [Analyzer](/plugins/analyzer) includes M/S visualization to see your stereo field in real-time. And our [Equalizer](/plugins/equalizer) supports independent Mid/Side bands for precise control.

---

*Want to learn more? Check out our [other tutorials](/resources).*
`,author:"Amp Spot Team",publishedAt:"2024-01-10",tags:["Tutorial","Mixing","Mastering"],readTime:5},{slug:"eq-tips-cleaner-mixes",title:"5 EQ Tips for Cleaner Mixes",excerpt:"EQ is the most fundamental mixing tool. These five tips will help you carve out space for each element and achieve cleaner, more professional mixes.",content:`
# 5 EQ Tips for Cleaner Mixes

Equalization is the foundation of good mixing. Get your EQ right, and everything else falls into place. Here are five tips to level up your EQ game.

## 1. Cut Before You Boost

The golden rule of EQ: **subtractive EQ is almost always better than additive EQ**.

When something doesn't sound right, our instinct is to boost frequencies we think are missing. But most problems are caused by too much of something, not too little.

**Try this instead:**
- Need more clarity? Cut mud from 200-400Hz
- Want more presence? Cut boxiness from 500-800Hz
- Looking for air? Clean up 4-6kHz before boosting at 10kHz+

Boosts add energy and can cause buildup. Cuts create space and clarity.

## 2. Use High-Pass Filters Religiously

Most instruments don't need energy below their fundamental frequency.

**General starting points:**
- Acoustic guitars: 80-100Hz
- Electric guitars: 100-120Hz
- Vocals: 100-120Hz
- Synths/pads: 150-200Hz
- Keyboards: 100-150Hz

Even instruments with low fundamentals often benefit from HPF below 40-50Hz to remove rumble and subs you can't hear but that eat up headroom.

## 3. Find the Problem Frequencies

Instead of guessing, use a sweeping technique:

1. Boost a narrow band (Q of 5-10) by 6-10dB
2. Sweep across the frequency spectrum
3. Listen for what sounds worst
4. That's your problem frequency—cut there

This "search and destroy" approach is faster and more accurate than random adjustments.

## 4. Consider Context, Not Solo

Instruments that sound great solo often sound terrible in a mix. Inversely, something that sounds weird in isolation might sit perfectly in the full track.

**Mix in context:**
- EQ while listening to the whole mix
- Toggle your EQ on and off to hear the difference
- Check how changes affect other instruments

Your job isn't to make each instrument sound perfect alone—it's to make them work together.

## 5. Use Broad Cuts, Narrow Boosts

Different problems require different solutions:

**For cuts (removing problems):**
- Use wider bandwidth (Q of 1-3)
- Musical, natural-sounding removal
- Less phase issues

**For boosts (adding character):**
- Use narrower bandwidth (Q of 3-6)
- More surgical, intentional enhancement
- Precise control without affecting nearby frequencies

## Bonus: Use Reference Tracks

EQ in a vacuum and you'll lose perspective. Load a pro mix in your DAW and reference it throughout your process. Not to copy, but to calibrate your ears.

## Putting It Together

The [Amp Spot Equalizer](/plugins/equalizer) is designed with these principles in mind:
- Clean, musical filters for surgical cuts
- Visual feedback to see what you're doing
- Low-latency processing that doesn't color your sound

[Download the free trial](/download) and hear the difference.

---

*Questions about EQ? Join our [Discord community](/community) or browse our [tutorials](/resources).*
`,author:"Amp Spot Team",publishedAt:"2024-01-05",tags:["Tutorial","Mixing","EQ"],readTime:6}];function r(){let e=a.sort((e,t)=>new Date(t.publishedAt).getTime()-new Date(e.publishedAt).getTime()).slice(0,2);return 0===e.length?null:(0,t.jsx)("section",{className:"bg-slate-800/30 backdrop-blur-sm py-20",children:(0,t.jsxs)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:[(0,t.jsxs)("div",{className:"flex items-end justify-between mb-10",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white sm:text-4xl",children:"Latest from the Blog"}),(0,t.jsx)("p",{className:"mt-2 text-lg text-gray-400",children:"Tips, tutorials, and insights for better audio production"})]}),(0,t.jsxs)(s.default,{href:"/blog",className:"hidden sm:inline-flex items-center gap-2 text-orange-400 hover:text-orange-300 font-medium transition-colors",children:["View all posts",(0,t.jsx)("svg",{className:"h-4 w-4",fill:"none",viewBox:"0 0 24 24",strokeWidth:2,stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"})})]})]}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:e.map(e=>(0,t.jsx)(s.default,{href:`/blog/${e.slug}`,className:"group block bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 overflow-hidden hover:border-orange-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-orange-500/10",children:(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 text-sm text-gray-400 mb-3",children:[(0,t.jsx)("span",{children:e.author}),(0,t.jsx)("span",{children:"•"}),(0,t.jsx)("span",{children:new Date(e.publishedAt).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}),(0,t.jsx)("span",{children:"•"}),(0,t.jsxs)("span",{children:[e.readTime," min read"]})]}),(0,t.jsx)("h3",{className:"text-xl font-semibold text-white mb-2 group-hover:text-orange-400 transition-colors",children:e.title}),(0,t.jsx)("p",{className:"text-gray-400 line-clamp-2",children:e.excerpt}),(0,t.jsx)("div",{className:"flex flex-wrap gap-2 mt-4",children:e.tags.map(e=>(0,t.jsx)("span",{className:"inline-flex items-center rounded-full bg-orange-500/10 px-3 py-1 text-xs font-medium text-orange-400",children:e},e))})]})},e.slug))}),(0,t.jsx)("div",{className:"mt-6 text-center sm:hidden",children:(0,t.jsxs)(s.default,{href:"/blog",className:"inline-flex items-center gap-2 text-orange-400 hover:text-orange-300 font-medium transition-colors",children:["View all posts",(0,t.jsx)("svg",{className:"h-4 w-4",fill:"none",viewBox:"0 0 24 24",strokeWidth:2,stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"})})]})})]})})}e.s(["LatestBlog",()=>r],5267),e.i(49134),e.i(42344),e.i(62449),e.s([],68855)},67888,e=>{"use strict";var t=e.i(47544),s=e.i(29505),o=e.i(75257);e.i(68855);var i=e.i(62449);function a(){let[e,a]=(0,o.useState)("all"),r=[{id:1,platform:"youtube",title:"How to Use EQ to Fix Muddy Mixes",description:"Learn the secrets of carving space in your mix with EQ.",thumbnail:"/images/social/yt-1.jpg",link:"https://youtube.com/@ampspot",date:"2024-02-10",icon:"▶️",color:"bg-red-600"},{id:2,platform:"instagram",title:"Quick Mixing Tip: High-Pass Everything",description:"Except the kick and bass 👊",thumbnail:"/images/social/ig-1.jpg",link:"https://instagram.com/ampspotaudio",date:"2024-02-09",icon:"📸",color:"bg-pink-600"},{id:3,platform:"youtube",title:"Compression Masterclass for Beginners",description:"Everything you need to know to start using compression effectively.",thumbnail:"/images/social/yt-2.jpg",link:"https://youtube.com/@ampspot",date:"2024-02-08",icon:"▶️",color:"bg-red-600"},{id:4,platform:"facebook",title:"New Plugin Update Released!",description:"Version 2.1 brings performance improvements and new presets",thumbnail:"/images/social/fb-1.jpg",link:"https://facebook.com/ampspotaudio",date:"2024-02-07",icon:"👍",color:"bg-blue-600"},{id:5,platform:"instagram",title:"Behind the Scenes: Recording Vocals",description:"Watch how we capture clean vocal takes in our studio",thumbnail:"/images/social/ig-2.jpg",link:"https://instagram.com/ampspotaudio",date:"2024-02-06",icon:"📸",color:"bg-pink-600"},{id:6,platform:"youtube",title:"Amp Spot EQ Plugin - Full Walkthrough",description:"Discover all the features of our flagship EQ plugin.",thumbnail:"/images/social/yt-3.jpg",link:"https://youtube.com/@ampspot",date:"2024-02-05",icon:"▶️",color:"bg-red-600"}],n="all"===e?r:r.filter(t=>t.platform===e);return(0,t.jsxs)("div",{className:"min-h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950",children:[(0,t.jsxs)("section",{className:"relative overflow-hidden bg-gradient-to-br from-orange-600 via-purple-600 to-pink-600 py-24 sm:py-32",children:[(0,t.jsx)("div",{className:"absolute inset-0 opacity-10",children:(0,t.jsx)(i.AudioBars,{count:20,minHeight:40,maxHeight:40,minOpacity:.3,maxOpacity:.7})}),(0,t.jsx)("div",{className:"relative mx-auto max-w-7xl px-6 lg:px-8",children:(0,t.jsxs)("div",{className:"mx-auto max-w-3xl text-center",children:[(0,t.jsx)("h1",{className:"text-4xl font-bold tracking-tight text-white sm:text-6xl",children:"Follow Amp Spot Everywhere"}),(0,t.jsx)("p",{className:"mt-6 text-lg leading-8 text-white/90 sm:text-xl",children:"Tutorials, tips, behind-the-scenes content, and community updates across all platforms"}),(0,t.jsxs)("div",{className:"mt-10 flex flex-wrap items-center justify-center gap-4",children:[(0,t.jsxs)("a",{href:"https://youtube.com/@ampspot",target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center gap-2 rounded-full bg-red-600 px-6 py-3 text-sm font-semibold text-white shadow-lg hover:bg-red-500 transition-all",children:[(0,t.jsx)("svg",{className:"h-5 w-5",fill:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{fillRule:"evenodd",d:"M19.812 5.418c.861.23 1.538.907 1.768 1.768C21.998 8.746 22 12 22 12s0 3.255-.418 4.814a2.504 2.504 0 0 1-1.768 1.768c-1.56.419-7.814.419-7.814.419s-6.255 0-7.814-.419a2.505 2.505 0 0 1-1.768-1.768C2 15.255 2 12 2 12s0-3.255.417-4.814a2.507 2.507 0 0 1 1.768-1.768C5.744 5 11.998 5 11.998 5s6.255 0 7.814.418ZM15.194 12 10 15V9l5.194 3Z",clipRule:"evenodd"})}),"YouTube"]}),(0,t.jsxs)("a",{href:"https://instagram.com/ampspotaudio",target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center gap-2 rounded-full bg-pink-600 px-6 py-3 text-sm font-semibold text-white shadow-lg hover:bg-pink-500 transition-all",children:[(0,t.jsx)("svg",{className:"h-5 w-5",fill:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{fillRule:"evenodd",d:"M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z",clipRule:"evenodd"})}),"Instagram"]}),(0,t.jsxs)("a",{href:"https://facebook.com/ampspotaudio",target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center gap-2 rounded-full bg-blue-600 px-6 py-3 text-sm font-semibold text-white shadow-lg hover:bg-blue-500 transition-all",children:[(0,t.jsx)("svg",{className:"h-5 w-5",fill:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{fillRule:"evenodd",d:"M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z",clipRule:"evenodd"})}),"Facebook"]})]})]})})]}),(0,t.jsx)("section",{className:"py-16 sm:py-24",children:(0,t.jsxs)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:[(0,t.jsxs)("div",{className:"mb-12 text-center",children:[(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white sm:text-4xl",children:"Latest Content"}),(0,t.jsx)("p",{className:"mt-4 text-lg text-gray-400",children:"Fresh updates from all our social platforms"})]}),(0,t.jsx)("div",{className:"mb-8 flex flex-wrap justify-center gap-4",children:[{id:"all",label:"All Posts",icon:"🌐"},{id:"youtube",label:"YouTube",icon:"▶️"},{id:"instagram",label:"Instagram",icon:"📸"},{id:"facebook",label:"Facebook",icon:"👍"}].map(s=>(0,t.jsxs)("button",{onClick:()=>a(s.id),className:`rounded-full px-6 py-2 text-sm font-semibold transition-all ${e===s.id?"bg-orange-600 text-white shadow-lg":"bg-slate-800 text-gray-400 hover:bg-slate-700"}`,children:[(0,t.jsx)("span",{className:"mr-2",children:s.icon}),s.label]},s.id))}),(0,t.jsx)("div",{className:"grid gap-6 sm:grid-cols-2 lg:grid-cols-3",children:n.map(e=>(0,t.jsxs)("a",{href:e.link,target:"_blank",rel:"noopener noreferrer",className:"group relative overflow-hidden rounded-2xl bg-slate-800/50 border border-slate-700/50 transition-all hover:bg-slate-800 hover:shadow-xl hover:shadow-orange-500/10 hover:border-orange-500/50",children:[(0,t.jsx)("div",{className:"absolute top-4 left-4 z-10",children:(0,t.jsxs)("span",{className:`inline-flex items-center rounded-full ${e.color} px-3 py-1 text-xs font-semibold text-white shadow-lg`,children:[(0,t.jsx)("span",{className:"mr-1",children:e.icon}),e.platform.charAt(0).toUpperCase()+e.platform.slice(1)]})}),(0,t.jsx)("div",{className:"relative aspect-video bg-gradient-to-br from-slate-700 to-slate-800",children:(0,t.jsx)("div",{className:"absolute inset-0 flex items-center justify-center",children:(0,t.jsx)("div",{className:`rounded-full ${e.color}/80 p-4 group-hover:scale-110 transition-transform`,children:(0,t.jsx)("svg",{className:"h-10 w-10 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{d:"M8 5v14l11-7z"})})})})}),(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsx)("h3",{className:"font-semibold text-white group-hover:text-orange-400 transition-colors line-clamp-2",children:e.title}),(0,t.jsx)("p",{className:"mt-2 text-sm text-gray-400 line-clamp-2",children:e.description}),(0,t.jsxs)("div",{className:"mt-4 flex items-center justify-between text-xs text-gray-500",children:[(0,t.jsx)("span",{children:new Date(e.date).toLocaleDateString("en-US",{month:"short",day:"numeric"})}),(0,t.jsxs)("span",{className:"flex items-center gap-1",children:["View Post",(0,t.jsx)("svg",{className:"h-3 w-3",fill:"none",viewBox:"0 0 24 24",strokeWidth:"2",stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"})})]})]})]})]},e.id))})]})}),(0,t.jsx)("section",{className:"py-16 sm:py-24 bg-slate-950/50",children:(0,t.jsxs)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:[(0,t.jsxs)("div",{className:"mb-12 text-center",children:[(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white sm:text-4xl",children:"Coming Soon"}),(0,t.jsx)("p",{className:"mt-4 text-lg text-gray-400",children:"Here is what we are working on for the next 2 weeks"})]}),(0,t.jsx)("div",{className:"grid gap-6 md:grid-cols-2 lg:grid-cols-2",children:[{title:"Mastering Your First Track",description:"A complete guide to taking your mix to the final stage.",platform:"YouTube",scheduledDate:"Feb 18, 2024",status:"In Production",statusColor:"bg-blue-500/20 text-blue-400"},{title:"Vocal Processing Tips Series",description:"Multi-part series covering all aspects of vocal production.",platform:"YouTube + Instagram",scheduledDate:"Feb 22, 2024",status:"Editing",statusColor:"bg-purple-500/20 text-purple-400"},{title:"Live Q&A Session",description:"Join us for a live session answering your mixing questions.",platform:"Facebook Live",scheduledDate:"Feb 25, 2024",status:"Scheduled",statusColor:"bg-green-500/20 text-green-400"},{title:"New Plugin Teaser",description:"First look at our upcoming saturation plugin.",platform:"All Platforms",scheduledDate:"Mar 1, 2024",status:"Planning",statusColor:"bg-orange-500/20 text-orange-400"}].map((e,s)=>(0,t.jsxs)("div",{className:"relative overflow-hidden rounded-2xl bg-slate-800/50 border border-slate-700/50 p-6 backdrop-blur-sm hover:border-orange-500/30 transition-all",children:[(0,t.jsxs)("div",{className:"flex items-start justify-between mb-4",children:[(0,t.jsxs)("div",{className:"flex-1",children:[(0,t.jsx)("span",{className:`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${e.statusColor}`,children:e.status}),(0,t.jsxs)("div",{className:"mt-3 flex items-center gap-2 text-sm text-gray-400",children:[(0,t.jsx)("svg",{className:"h-4 w-4",fill:"none",viewBox:"0 0 24 24",strokeWidth:"2",stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"})}),e.scheduledDate]})]}),(0,t.jsx)("div",{className:"h-2 w-2 rounded-full bg-orange-500 animate-pulse flex-shrink-0"})]}),(0,t.jsx)("h3",{className:"text-xl font-semibold text-white mb-2",children:e.title}),(0,t.jsx)("p",{className:"text-sm text-gray-400 mb-4",children:e.description}),(0,t.jsxs)("div",{className:"flex items-center gap-2 text-xs text-orange-400 font-semibold",children:[(0,t.jsx)("svg",{className:"h-4 w-4",fill:"none",viewBox:"0 0 24 24",strokeWidth:"2",stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"})}),e.platform]})]},s))})]})}),(0,t.jsxs)("section",{className:"relative overflow-hidden bg-gradient-to-br from-orange-600 via-purple-600 to-pink-600 py-16 sm:py-24",children:[(0,t.jsx)("div",{className:"absolute inset-0 opacity-10",children:(0,t.jsx)(i.AudioBars,{count:30,minHeight:30,maxHeight:50,minOpacity:.2,maxOpacity:.5})}),(0,t.jsxs)("div",{className:"relative mx-auto max-w-4xl px-6 lg:px-8 text-center",children:[(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white sm:text-4xl",children:"Never Miss an Update"}),(0,t.jsx)("p",{className:"mt-4 text-lg text-white/90",children:"Follow us on all platforms to get the latest tutorials, tips, and exclusive content"}),(0,t.jsxs)("div",{className:"mt-8 flex flex-wrap justify-center gap-4",children:[(0,t.jsx)("a",{href:"https://youtube.com/@ampspot",target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-semibold text-orange-600 shadow-lg hover:bg-orange-50 transition-all",children:"Subscribe on YouTube"}),(0,t.jsx)(s.default,{href:"/blog",className:"inline-flex items-center gap-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 px-6 py-3 text-sm font-semibold text-white hover:bg-white/20 transition-all",children:"Read the Blog"})]})]})]})]})}e.s(["default",()=>a])}]);