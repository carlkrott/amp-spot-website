var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/plugins/[id]/download/route.js")
R.c("server/chunks/[root-of-the-server]__3b8fc439._.js")
R.c("server/chunks/[root-of-the-server]__85d1ac87._.js")
R.c("server/chunks/[root-of-the-server]__b9bafd6a._.js")
R.c("server/chunks/[root-of-the-server]__5e4dad72._.js")
R.c("server/chunks/dcefb__next-internal_server_app_api_plugins_[id]_download_route_actions_88810a6c.js")
R.m(6879)
module.exports=R.m(6879).exports
