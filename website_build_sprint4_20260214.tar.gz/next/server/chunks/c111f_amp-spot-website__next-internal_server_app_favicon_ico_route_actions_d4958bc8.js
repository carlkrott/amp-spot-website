module.exports=[82763,(e,o,d)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_favicon_ico_route_actions_d4958bc8.js.map