module.exports=[33758,(a,b,c)=>{}];

//# sourceMappingURL=ddd5b_workspace_amp-spot-website__next-internal_server_app_page_actions_65a0b256.js.map