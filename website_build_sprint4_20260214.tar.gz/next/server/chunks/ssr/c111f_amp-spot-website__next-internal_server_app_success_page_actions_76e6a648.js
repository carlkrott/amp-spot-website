module.exports=[609,(a,b,c)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_success_page_actions_76e6a648.js.map