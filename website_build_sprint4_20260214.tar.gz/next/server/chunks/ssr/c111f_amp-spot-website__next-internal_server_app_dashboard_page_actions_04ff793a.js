module.exports=[33940,(a,b,c)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_dashboard_page_actions_04ff793a.js.map