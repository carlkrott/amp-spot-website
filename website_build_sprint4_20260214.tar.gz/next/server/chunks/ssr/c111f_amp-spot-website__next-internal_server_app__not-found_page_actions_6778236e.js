module.exports=[42681,(a,b,c)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app__not-found_page_actions_6778236e.js.map