module.exports=[3711,(e,o,d)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_robots_txt_route_actions_8386c50f.js.map