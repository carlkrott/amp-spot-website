var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_b01ab6e1._.js")
R.c("server/chunks/[root-of-the-server]__5e4dad72._.js")
R.c("server/chunks/3328a_next_dist_esm_build_templates_app-route_1fbfbf02.js")
R.c("server/chunks/c111f_amp-spot-website__next-internal_server_app_favicon_ico_route_actions_d4958bc8.js")
R.m(44858)
module.exports=R.m(44858).exports
