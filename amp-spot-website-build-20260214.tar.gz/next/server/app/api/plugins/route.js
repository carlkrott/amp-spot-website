var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/plugins/route.js")
R.c("server/chunks/[root-of-the-server]__8d397de7._.js")
R.c("server/chunks/d6398_zod_v4_classic_external_84a51db8.js")
R.c("server/chunks/[root-of-the-server]__5e4dad72._.js")
R.c("server/chunks/c111f_amp-spot-website__next-internal_server_app_api_plugins_route_actions_9b2b41f3.js")
R.m(8355)
module.exports=R.m(8355).exports
