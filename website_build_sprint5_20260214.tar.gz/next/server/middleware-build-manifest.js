globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/4ace12262fe219a2.js",
    "static/chunks/4176817a0f972cd1.js",
    "static/chunks/8b6894ba906ab07c.js",
    "static/chunks/75ad89d672d09353.js",
    "static/chunks/turbopack-74eb2c15dd7ff0ce.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];