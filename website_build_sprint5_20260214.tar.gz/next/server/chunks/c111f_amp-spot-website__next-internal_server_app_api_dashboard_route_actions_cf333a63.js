module.exports=[79313,(e,o,d)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_api_dashboard_route_actions_cf333a63.js.map