module.exports=[14482,(a,b,c)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_youtube_page_actions_c49ce97e.js.map