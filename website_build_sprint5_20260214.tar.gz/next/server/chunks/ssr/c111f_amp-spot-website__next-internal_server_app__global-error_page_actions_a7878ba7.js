module.exports=[77744,(a,b,c)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app__global-error_page_actions_a7878ba7.js.map