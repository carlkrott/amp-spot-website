module.exports=[384,(a,b,c)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_subscription_page_actions_8e2fcdbe.js.map