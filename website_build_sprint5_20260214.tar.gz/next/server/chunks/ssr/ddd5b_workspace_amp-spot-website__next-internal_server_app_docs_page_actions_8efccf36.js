module.exports=[60441,(a,b,c)=>{}];

//# sourceMappingURL=ddd5b_workspace_amp-spot-website__next-internal_server_app_docs_page_actions_8efccf36.js.map