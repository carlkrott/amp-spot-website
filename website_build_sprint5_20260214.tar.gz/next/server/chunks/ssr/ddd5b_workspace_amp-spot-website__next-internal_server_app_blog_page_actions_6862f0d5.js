module.exports=[29849,(a,b,c)=>{}];

//# sourceMappingURL=ddd5b_workspace_amp-spot-website__next-internal_server_app_blog_page_actions_6862f0d5.js.map