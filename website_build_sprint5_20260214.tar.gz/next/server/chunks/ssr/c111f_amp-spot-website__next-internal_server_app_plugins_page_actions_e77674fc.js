module.exports=[37229,(a,b,c)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_plugins_page_actions_e77674fc.js.map