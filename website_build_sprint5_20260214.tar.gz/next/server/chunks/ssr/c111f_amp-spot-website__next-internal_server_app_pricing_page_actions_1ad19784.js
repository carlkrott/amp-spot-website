module.exports=[87346,(a,b,c)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_pricing_page_actions_1ad19784.js.map