module.exports=[75077,(a,b,c)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_blog_%5Bslug%5D_page_actions_10cac915.js.map