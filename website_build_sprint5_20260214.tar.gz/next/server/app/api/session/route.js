var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/session/route.js")
R.c("server/chunks/[root-of-the-server]__694c75c3._.js")
R.c("server/chunks/[root-of-the-server]__85d1ac87._.js")
R.c("server/chunks/[root-of-the-server]__b9bafd6a._.js")
R.c("server/chunks/[root-of-the-server]__5e4dad72._.js")
R.c("server/chunks/c111f_amp-spot-website__next-internal_server_app_api_session_route_actions_8b114be9.js")
R.m(12368)
module.exports=R.m(12368).exports
