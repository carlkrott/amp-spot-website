var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/plugins/route.js")
R.c("server/chunks/[root-of-the-server]__e622774e._.js")
R.c("server/chunks/[root-of-the-server]__b9bafd6a._.js")
R.c("server/chunks/[root-of-the-server]__5e4dad72._.js")
R.c("server/chunks/c111f_amp-spot-website__next-internal_server_app_api_plugins_route_actions_9b2b41f3.js")
R.m(8355)
module.exports=R.m(8355).exports
