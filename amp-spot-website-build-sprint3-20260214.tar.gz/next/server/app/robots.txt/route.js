var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__94cd8ec7._.js")
R.c("server/chunks/[root-of-the-server]__5e4dad72._.js")
R.c("server/chunks/c111f_amp-spot-website__next-internal_server_app_robots_txt_route_actions_8386c50f.js")
R.m(86355)
module.exports=R.m(86355).exports
