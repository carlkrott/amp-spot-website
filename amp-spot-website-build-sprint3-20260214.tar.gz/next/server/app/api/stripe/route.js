var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/stripe/route.js")
R.c("server/chunks/[root-of-the-server]__1d90c122._.js")
R.c("server/chunks/[root-of-the-server]__85d1ac87._.js")
R.c("server/chunks/[root-of-the-server]__b9bafd6a._.js")
R.c("server/chunks/[root-of-the-server]__5e4dad72._.js")
R.c("server/chunks/c111f_amp-spot-website__next-internal_server_app_api_stripe_route_actions_0af0ce79.js")
R.m(36686)
module.exports=R.m(36686).exports
