var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__1831e7f8._.js")
R.c("server/chunks/[root-of-the-server]__85d1ac87._.js")
R.c("server/chunks/[root-of-the-server]__b9bafd6a._.js")
R.c("server/chunks/[root-of-the-server]__5e4dad72._.js")
R.c("server/chunks/c111f_amp-spot-website__next-internal_server_app_api_dashboard_route_actions_cf333a63.js")
R.m(6141)
module.exports=R.m(6141).exports
