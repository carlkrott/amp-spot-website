module.exports=[83567,(a,b,c)=>{"use strict";b.exports=a.r(50342).vendored["react-ssr"].ReactJsxRuntime},33182,(a,b,c)=>{"use strict";b.exports=a.r(50342).vendored.contexts.AppRouterContext},24514,(a,b,c)=>{"use strict";b.exports=a.r(50342).vendored["react-ssr"].ReactServerDOMTurbopackClient}];

//# sourceMappingURL=3328a_next_dist_server_route-modules_app-page_vendored_de03bb23._.js.map