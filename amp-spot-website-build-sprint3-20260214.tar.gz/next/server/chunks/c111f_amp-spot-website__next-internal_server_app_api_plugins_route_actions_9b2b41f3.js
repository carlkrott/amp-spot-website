module.exports=[19936,(e,o,d)=>{}];

//# sourceMappingURL=c111f_amp-spot-website__next-internal_server_app_api_plugins_route_actions_9b2b41f3.js.map