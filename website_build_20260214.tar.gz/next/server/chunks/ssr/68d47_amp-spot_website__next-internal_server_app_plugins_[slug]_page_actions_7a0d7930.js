module.exports=[61990,(a,b,c)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_plugins_%5Bslug%5D_page_actions_7a0d7930.js.map