module.exports=[19321,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},85322,a=>{"use strict";let b={src:a.i(19321).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=_openclaw_workspace_projects_amp-spot_website_src_app_9eb4e553._.js.map