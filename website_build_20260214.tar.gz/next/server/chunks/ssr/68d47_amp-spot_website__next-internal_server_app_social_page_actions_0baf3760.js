module.exports=[24667,(a,b,c)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_social_page_actions_0baf3760.js.map