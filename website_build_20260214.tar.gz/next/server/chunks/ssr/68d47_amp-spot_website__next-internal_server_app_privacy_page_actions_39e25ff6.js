module.exports=[90746,(a,b,c)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_privacy_page_actions_39e25ff6.js.map