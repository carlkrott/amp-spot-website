module.exports=[14803,(a,b,c)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_youtube_page_actions_acea607e.js.map