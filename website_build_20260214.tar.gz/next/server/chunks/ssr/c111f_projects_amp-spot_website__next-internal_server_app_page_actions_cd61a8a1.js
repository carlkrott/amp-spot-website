module.exports=[42949,(a,b,c)=>{}];

//# sourceMappingURL=c111f_projects_amp-spot_website__next-internal_server_app_page_actions_cd61a8a1.js.map