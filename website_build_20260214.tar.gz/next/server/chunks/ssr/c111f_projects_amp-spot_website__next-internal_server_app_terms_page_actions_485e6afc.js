module.exports=[74591,(a,b,c)=>{}];

//# sourceMappingURL=c111f_projects_amp-spot_website__next-internal_server_app_terms_page_actions_485e6afc.js.map