module.exports=[23124,(a,b,c)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app__not-found_page_actions_1e36e3cb.js.map