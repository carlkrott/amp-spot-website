module.exports=[46536,(a,b,c)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_plugins_page_actions_daccd8fd.js.map