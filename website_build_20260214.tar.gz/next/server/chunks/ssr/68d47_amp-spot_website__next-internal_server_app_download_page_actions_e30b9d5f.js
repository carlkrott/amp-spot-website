module.exports=[22313,(a,b,c)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_download_page_actions_e30b9d5f.js.map