module.exports=[29534,(a,b,c)=>{}];

//# sourceMappingURL=c111f_projects_amp-spot_website__next-internal_server_app_blog_page_actions_b59ae0be.js.map