module.exports=[18977,(e,o,d)=>{}];

//# sourceMappingURL=68d47_amp-spot_website__next-internal_server_app_sitemap_xml_route_actions_d484796a.js.map