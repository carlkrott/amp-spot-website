module.exports=[64178,(e,o,d)=>{}];

//# sourceMappingURL=dbe0f_website__next-internal_server_app_api_plugins_%5Bslug%5D_route_actions_3cdf919a.js.map