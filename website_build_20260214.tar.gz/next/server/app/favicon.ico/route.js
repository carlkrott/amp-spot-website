var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__7040479c._.js")
R.c("server/chunks/712f4_next_dist_esm_build_templates_app-route_6df82d53.js")
R.c("server/chunks/68d47_amp-spot_website__next-internal_server_app_favicon_ico_route_actions_1ba10ea7.js")
R.m(28207)
module.exports=R.m(28207).exports
