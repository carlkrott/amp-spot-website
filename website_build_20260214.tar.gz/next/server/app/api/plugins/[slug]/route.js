var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/plugins/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__1ace04d4._.js")
R.c("server/chunks/[root-of-the-server]__7040479c._.js")
R.c("server/chunks/[root-of-the-server]__a10b1f85._.js")
R.c("server/chunks/dbe0f_website__next-internal_server_app_api_plugins_[slug]_route_actions_3cdf919a.js")
R.m(85038)
module.exports=R.m(85038).exports
