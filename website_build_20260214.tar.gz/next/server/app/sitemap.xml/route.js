var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__9b833c4e._.js")
R.c("server/chunks/[root-of-the-server]__7040479c._.js")
R.c("server/chunks/712f4_next_dist_d0be4c2f._.js")
R.c("server/chunks/68d47_amp-spot_website__next-internal_server_app_sitemap_xml_route_actions_d484796a.js")
R.m(73084)
module.exports=R.m(73084).exports
