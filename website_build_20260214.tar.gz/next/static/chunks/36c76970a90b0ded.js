(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,68855,86252,5267,e=>{"use strict";e.i(97786),e.i(48370),e.i(29263);var t=e.i(47544),s=e.i(29505);function o({plugin:e}){return(0,t.jsxs)(s.default,{href:`/plugins/${e.slug}`,className:"group relative overflow-hidden rounded-2xl bg-slate-800/50 p-6 backdrop-blur-sm transition-all hover:bg-slate-800/70 hover:shadow-xl hover:shadow-purple-500/10",children:[(0,t.jsx)("div",{className:"absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 transition-opacity group-hover:opacity-100"}),(0,t.jsxs)("div",{className:"relative",children:[2===e.phase&&(0,t.jsx)("span",{className:"mb-3 inline-flex items-center rounded-full bg-amber-500/20 px-3 py-1 text-xs font-medium text-amber-400",children:"Coming Soon"}),(0,t.jsx)("h3",{className:"text-xl font-bold text-white group-hover:text-purple-300 transition-colors",children:e.title}),(0,t.jsx)("p",{className:"mt-2 text-sm font-medium text-purple-400",children:e.tagline}),(0,t.jsx)("p",{className:"mt-4 text-gray-400 line-clamp-3",children:e.description}),(0,t.jsxs)("div",{className:"mt-6 flex items-center text-sm font-medium text-purple-400 group-hover:text-purple-300",children:["Learn more",(0,t.jsx)("svg",{className:"ml-2 h-4 w-4 transition-transform group-hover:translate-x-1",fill:"none",viewBox:"0 0 24 24",strokeWidth:"2",stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"})})]})]})]})}function i({plugins:e,title:s,subtitle:i}){return(0,t.jsx)("section",{id:"plugins",className:"bg-slate-900 py-24 sm:py-32",children:(0,t.jsxs)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:[(s||i)&&(0,t.jsxs)("div",{className:"mx-auto max-w-2xl text-center mb-16",children:[s&&(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white sm:text-4xl",children:s}),i&&(0,t.jsx)("p",{className:"mt-4 text-lg text-gray-400",children:i})]}),(0,t.jsx)("div",{className:"grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3",children:e.map(e=>(0,t.jsx)(o,{plugin:e},e.slug))})]})})}e.s(["PluginGrid",()=>i],86252);let a=[{slug:"how-to-fix-muddy-mixes-eq-tutorial",title:"How to Fix Muddy Mixes with EQ (Video Tutorial)",excerpt:"Watch our step-by-step video guide on eliminating mud from your mixes using surgical EQ techniques. Learn exactly where to cut and how much.",content:`
# How to Fix Muddy Mixes with EQ

Muddy mixes are one of the most common problems in music production. In this video tutorial, we show you exactly how to identify and remove mud using EQ.

## Watch the Full Tutorial

<div class="aspect-video w-full bg-slate-800 rounded-xl flex items-center justify-center">
  <a href="https://youtube.com/@ampspot" target="_blank" class="text-orange-500">Watch on YouTube</a>
</div>

## Key Takeaways

### 1. Identify the Problem Frequencies
- **200-400Hz** is where most mud lives
- Use a sweeping technique to find the exact frequency
- Boost first to find, then cut to fix

### 2. Use Subtractive EQ
- Start with gentle cuts (2-4dB)
- Use moderate Q values (1-3) for natural sound
- Don't overdo it—subtle changes add up

### 3. Check in Context
- Always EQ while listening to the full mix
- Solo can be misleading
- Toggle your EQ on/off to verify improvement

### 4. Address Multiple Instruments
- Mud often comes from frequency buildup
- EQ several instruments slightly instead of one drastically
- Create separation between similar instruments

## Tools Used in This Video

We used the [Amp Spot EQ Plugin](/plugins/eq) for all demonstrations in this video. It's free to try for 14 days.

## What's Next?

Want more mixing tutorials? Subscribe to our [YouTube channel](https://youtube.com/@ampspot) and check out our [blog](/blog) for written guides.

---

*Video published February 10, 2024 • Runtime: 12:34*
`,author:"Amp Spot Team",publishedAt:"2024-02-10",tags:["Video","Tutorial","Mixing","EQ"],readTime:4},{slug:"compression-for-beginners-masterclass",title:"Compression Masterclass for Beginners (Full Video)",excerpt:"Everything you need to know about compression in one comprehensive video tutorial. From basic concepts to advanced techniques.",content:`
# Compression Masterclass for Beginners

Compression can be intimidating for beginners, but it doesn't have to be. This video breaks down everything you need to know in simple, easy-to-understand terms.

## Watch the Full Masterclass

<div class="aspect-video w-full bg-slate-800 rounded-xl flex items-center justify-center">
  <a href="https://youtube.com/@ampspot" target="_blank" class="text-orange-500">Watch on YouTube</a>
</div>

## Topics Covered

### Part 1: Understanding Compression (0:00-8:45)
- What compression does to audio
- Why we use it in mixing and mastering
- Common misconceptions

### Part 2: The Four Main Controls (8:46-18:20)
- **Threshold**: When compression starts
- **Ratio**: How much compression applies
- **Attack**: How fast compression engages
- **Release**: How fast compression lets go

### Part 3: Practical Applications (18:21-32:15)
- Compressing vocals for consistency
- Drums: punch vs. sustain
- Bass: glue and control
- Master bus compression

### Part 4: Common Mistakes (32:16-42:00)
- Over-compressing (and how to avoid it)
- Wrong attack/release times
- Not using your ears
- Forgetting makeup gain

## Download the Session Files

Patreon supporters get access to the full session files used in this tutorial. [Join here](https://patreon.com/ampspot).

## Plugin Used

We used the [Amp Spot Compressor](/plugins/compressor) exclusively for this masterclass. Try it free for 14 days.

---

*Video published February 8, 2024 • Runtime: 42:18*
`,author:"Amp Spot Team",publishedAt:"2024-02-08",tags:["Video","Tutorial","Compression","Mixing"],readTime:6},{slug:"amp-spot-eq-plugin-walkthrough",title:"Amp Spot EQ Plugin - Complete Feature Walkthrough",excerpt:"Discover every feature of our flagship EQ plugin in this detailed walkthrough video. Learn tips, tricks, and hidden features.",content:`
# Amp Spot EQ Plugin - Complete Walkthrough

Get to know every feature, button, and workflow tip for the Amp Spot EQ plugin in this comprehensive video guide.

## Watch the Walkthrough

<div class="aspect-video w-full bg-slate-800 rounded-xl flex items-center justify-center">
  <a href="https://youtube.com/@ampspot" target="_blank" class="text-orange-500">Watch on YouTube</a>
</div>

## Features Covered

### The Interface (0:00-5:30)
- Main display and spectrum analyzer
- Band controls and frequency selection
- Preset management

### EQ Bands Explained (5:31-15:45)
- High-pass and low-pass filters
- Parametric bands (gain, frequency, Q)
- Shelving bands
- Mid/Side processing mode

### Advanced Features (15:46-25:20)
- Spectrum analyzer overlays
- A/B comparison mode
- Undo/redo functionality
- Preset browser and favorites

### Workflow Tips (25:21-32:50)
- Keyboard shortcuts
- Quick band copying
- Saving custom presets
- Integration with your DAW

### Sound Quality & Performance (32:51-38:00)
- Zero-latency design
- CPU usage optimization
- Oversampling options
- Analog modeling (coming in v2.0)

## Hidden Features

Did you know you can:
- **Double-click** a band to solo it
- **Option/Alt + drag** to adjust Q while moving frequency
- **Shift + click** to reset a parameter to default
- **Right-click** anywhere to access quick menu

## Download & Try

The EQ plugin is available now with a free 14-day trial. [Download here](/download).

---

*Video published February 5, 2024 • Runtime: 38:42*
`,author:"Amp Spot Team",publishedAt:"2024-02-05",tags:["Video","Product","EQ","Tutorial"],readTime:5},{slug:"introducing-amp-spot",title:"Introducing Amp Spot: Pro Audio Tools for Everyone",excerpt:"Professional audio plugins shouldn't cost a fortune. We're changing that with our suite of powerful, accessible tools for music producers of all levels.",content:`
# Introducing Amp Spot: Pro Audio Tools for Everyone

When we started Amp Spot, we had a simple mission: make professional-grade audio tools accessible to everyone, regardless of budget or experience level.

## The Problem

The audio plugin world has a problem. High-end plugins cost hundreds of dollars each, putting them out of reach for bedroom producers, students, and hobbyists. Free plugins often lack the polish and features that pros need.

We believed there had to be a middle ground.

## Our Solution

Amp Spot brings you professional-quality plugins at prices that make sense. Each plugin in our suite is designed with:

- **Transparent Algorithms**: No hidden processing, just clean audio path
- **Intuitive Interfaces**: Learn in minutes, master in hours
- **CPU-Friendly Design**: Run more instances, stay creative longer
- **Comprehensive Documentation**: Learn the why behind the what

## What's Available Now

Our Phase 1 launch includes essential mixing tools:

- **Equalizer**: Precision EQ with analog-modeled curves
- **Compressor**: Versatile dynamics control with multiple character modes
- **Analyzer**: Real-time spectrum, frequency, and correlation analysis
- **Saturation**: Harmonic richness with multiple saturation types
- **Transient Shaper**: Punch up or tame your attacks and sustain

## What's Next

We're already working on Phase 2, with more specialized tools including limiting, de-essing, and creative effects. Follow our blog for updates and tutorials.

## Try for Free

The best way to understand our approach? Try it yourself. All plugins come with a 14-day free trial—no credit card required.

[Download Now](/download)

---

*Have questions? Check our [FAQ](/faq) or [contact support](/support).*
`,author:"Amp Spot Team",publishedAt:"2024-01-15",tags:["Announcement","Product"],readTime:3},{slug:"mid-side-processing",title:"Understanding Mid/Side Processing",excerpt:"Mid/Side processing is a powerful technique for mixing and mastering. Learn how it works, when to use it, and how it can transform your stereo image.",content:`
# Understanding Mid/Side Processing

Mid/Side (M/S) processing is one of those techniques that sounds intimidating but offers powerful creative possibilities once you understand it. Let's break it down.

## What is Mid/Side?

Traditional stereo audio has two channels: Left and Right. Mid/Side processing reorganizes this information differently:

- **Mid (Mono)**: Everything that's the same in both speakers (center-panned elements)
- **Side (Stereo)**: Everything that's different between speakers (width, reverb, stereo effects)

Mathematically:
- Mid = Left + Right
- Side = Left - Right

## Why Use M/S Processing?

M/S processing opens up several possibilities:

### 1. EQ the Center and Sides Separately
Brighten vocals without harsh cymbals. Add clarity to your bass without affecting the stereo width.

### 2. Control Stereo Width
Boost the Side channel for wider mixes. Reduce it for focused, mono-compatible tracks.

### 3. Compression Strategies
Compress the Mid differently than the Sides—gentle on the sides for preserving space, harder on the mid for glue and punch.

### 4. Saturation Tricks
Add warmth to your center elements without making the whole track muddy.

## Practical Applications

### Vocal Processing
Apply brighter EQ only to the Mid channel where vocals live. Your vocals cut through without making cymbals harsh.

### Reverb Control
Reverb typically lives in the Side channel. You can EQ or saturate it independently to clean up muddy mixes.

### Low-End Management
Bass and kick should be mono. Use M/S EQ to ensure all low-frequency energy is in the Mid channel.

## Common Pitfalls

**Don't overdo it:** Subtle M/S processing is powerful. Heavy-handed M/S manipulation can cause phase issues and mono incompatibility.

**Check mono regularly:** Always test your mixes in mono. Excessive Side processing can collapse poorly.

**Trust your ears:** M/S analysis is cool, but if it sounds wrong, it is wrong.

## Try M/S Processing

Our [Analyzer](/plugins/analyzer) includes M/S visualization to see your stereo field in real-time. And our [Equalizer](/plugins/equalizer) supports independent Mid/Side bands for precise control.

---

*Want to learn more? Check out our [other tutorials](/resources).*
`,author:"Amp Spot Team",publishedAt:"2024-01-10",tags:["Tutorial","Mixing","Mastering"],readTime:5},{slug:"eq-tips-cleaner-mixes",title:"5 EQ Tips for Cleaner Mixes",excerpt:"EQ is the most fundamental mixing tool. These five tips will help you carve out space for each element and achieve cleaner, more professional mixes.",content:`
# 5 EQ Tips for Cleaner Mixes

Equalization is the foundation of good mixing. Get your EQ right, and everything else falls into place. Here are five tips to level up your EQ game.

## 1. Cut Before You Boost

The golden rule of EQ: **subtractive EQ is almost always better than additive EQ**.

When something doesn't sound right, our instinct is to boost frequencies we think are missing. But most problems are caused by too much of something, not too little.

**Try this instead:**
- Need more clarity? Cut mud from 200-400Hz
- Want more presence? Cut boxiness from 500-800Hz
- Looking for air? Clean up 4-6kHz before boosting at 10kHz+

Boosts add energy and can cause buildup. Cuts create space and clarity.

## 2. Use High-Pass Filters Religiously

Most instruments don't need energy below their fundamental frequency.

**General starting points:**
- Acoustic guitars: 80-100Hz
- Electric guitars: 100-120Hz
- Vocals: 100-120Hz
- Synths/pads: 150-200Hz
- Keyboards: 100-150Hz

Even instruments with low fundamentals often benefit from HPF below 40-50Hz to remove rumble and subs you can't hear but that eat up headroom.

## 3. Find the Problem Frequencies

Instead of guessing, use a sweeping technique:

1. Boost a narrow band (Q of 5-10) by 6-10dB
2. Sweep across the frequency spectrum
3. Listen for what sounds worst
4. That's your problem frequency—cut there

This "search and destroy" approach is faster and more accurate than random adjustments.

## 4. Consider Context, Not Solo

Instruments that sound great solo often sound terrible in a mix. Inversely, something that sounds weird in isolation might sit perfectly in the full track.

**Mix in context:**
- EQ while listening to the whole mix
- Toggle your EQ on and off to hear the difference
- Check how changes affect other instruments

Your job isn't to make each instrument sound perfect alone—it's to make them work together.

## 5. Use Broad Cuts, Narrow Boosts

Different problems require different solutions:

**For cuts (removing problems):**
- Use wider bandwidth (Q of 1-3)
- Musical, natural-sounding removal
- Less phase issues

**For boosts (adding character):**
- Use narrower bandwidth (Q of 3-6)
- More surgical, intentional enhancement
- Precise control without affecting nearby frequencies

## Bonus: Use Reference Tracks

EQ in a vacuum and you'll lose perspective. Load a pro mix in your DAW and reference it throughout your process. Not to copy, but to calibrate your ears.

## Putting It Together

The [Amp Spot Equalizer](/plugins/equalizer) is designed with these principles in mind:
- Clean, musical filters for surgical cuts
- Visual feedback to see what you're doing
- Low-latency processing that doesn't color your sound

[Download the free trial](/download) and hear the difference.

---

*Questions about EQ? Join our [Discord community](/community) or browse our [tutorials](/resources).*
`,author:"Amp Spot Team",publishedAt:"2024-01-05",tags:["Tutorial","Mixing","EQ"],readTime:6}];function r(){let e=a.sort((e,t)=>new Date(t.publishedAt).getTime()-new Date(e.publishedAt).getTime()).slice(0,2);return 0===e.length?null:(0,t.jsx)("section",{className:"bg-slate-800/30 backdrop-blur-sm py-20",children:(0,t.jsxs)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:[(0,t.jsxs)("div",{className:"flex items-end justify-between mb-10",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white sm:text-4xl",children:"Latest from the Blog"}),(0,t.jsx)("p",{className:"mt-2 text-lg text-gray-400",children:"Tips, tutorials, and insights for better audio production"})]}),(0,t.jsxs)(s.default,{href:"/blog",className:"hidden sm:inline-flex items-center gap-2 text-orange-400 hover:text-orange-300 font-medium transition-colors",children:["View all posts",(0,t.jsx)("svg",{className:"h-4 w-4",fill:"none",viewBox:"0 0 24 24",strokeWidth:2,stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"})})]})]}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:e.map(e=>(0,t.jsx)(s.default,{href:`/blog/${e.slug}`,className:"group block bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 overflow-hidden hover:border-orange-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-orange-500/10",children:(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsxs)("div",{className:"flex items-center gap-2 text-sm text-gray-400 mb-3",children:[(0,t.jsx)("span",{children:e.author}),(0,t.jsx)("span",{children:"•"}),(0,t.jsx)("span",{children:new Date(e.publishedAt).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}),(0,t.jsx)("span",{children:"•"}),(0,t.jsxs)("span",{children:[e.readTime," min read"]})]}),(0,t.jsx)("h3",{className:"text-xl font-semibold text-white mb-2 group-hover:text-orange-400 transition-colors",children:e.title}),(0,t.jsx)("p",{className:"text-gray-400 line-clamp-2",children:e.excerpt}),(0,t.jsx)("div",{className:"flex flex-wrap gap-2 mt-4",children:e.tags.map(e=>(0,t.jsx)("span",{className:"inline-flex items-center rounded-full bg-orange-500/10 px-3 py-1 text-xs font-medium text-orange-400",children:e},e))})]})},e.slug))}),(0,t.jsx)("div",{className:"mt-6 text-center sm:hidden",children:(0,t.jsxs)(s.default,{href:"/blog",className:"inline-flex items-center gap-2 text-orange-400 hover:text-orange-300 font-medium transition-colors",children:["View all posts",(0,t.jsx)("svg",{className:"h-4 w-4",fill:"none",viewBox:"0 0 24 24",strokeWidth:2,stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"})})]})})]})})}e.s(["LatestBlog",()=>r],5267),e.i(49134),e.i(42344),e.i(62449),e.s([],68855)},85022,e=>{"use strict";var t=e.i(75257);let s=t.forwardRef(function({title:e,titleId:s,...o},i){return t.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:i,"aria-labelledby":s},o),e?t.createElement("title",{id:s},e):null,t.createElement("path",{fillRule:"evenodd",d:"M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z",clipRule:"evenodd"}))});e.s(["CheckIcon",0,s],85022)},24028,e=>{"use strict";var t=e.i(47544),s=e.i(29505);e.i(68855);var o=e.i(86252),i=e.i(5267),a=e.i(62449);let r=[{slug:"eq",title:"Amp Spot EQ",tagline:"Surgical precision meets musical character.",description:"Our 7-band parametric EQ combines digital precision with analog warmth. Shape your sounds with transparent surgical cuts or add character with tube and transformer emulations. Whether you're carving space in a dense mix or adding final polish, Amp Spot EQ handles it all.",features:["7-band parametric EQ with multiple filter types per band","Analog mode with tube and transformer saturation options","Real-time spectrum analyzer overlay","Mid/side processing for stereo imaging","Low CPU usage with NIH-plug Rust engine"],phase:1,status:"coming-soon",metaTitle:"Amp Spot EQ - 7-Band Parametric EQ Plugin",metaDescription:"Professional 7-band parametric EQ with analog warmth. Surgical precision meets musical character. Built with Rust for low CPU usage.",ogImage:"/images/og/eq.png"},{slug:"compressor",title:"Amp Spot Compressor",tagline:"Tame dynamics, keep your soul.",description:"Control your dynamics without killing your music's life. Features authentic VU metering and multiple compression styles. The smart auto-mode makes it dead simple for beginners, while full manual control gives seasoned engineers precision.",features:["Authentic VU meter with realistic ballistics","Multiple compression models (VCA, FET, Opto)","Smart auto-mode for one-knob operation","Sidechain input with filtering options","Parallel compression with wet/dry mix"],phase:1,status:"coming-soon",metaTitle:"Amp Spot Compressor - Dynamic Control with VU Metering",metaDescription:"Professional compressor plugin with authentic VU metering. Tame dynamics without killing your music. Built with Rust.",ogImage:"/images/og/compressor.png"},{slug:"analyzer",title:"Amp Spot Analyzer",tagline:"See what your ears are telling you.",description:"Stop guessing and start knowing. Our real-time spectrum analyzer reveals exactly what's happening in your frequency spectrum. Learn to trust your ears faster by seeing the correlation between what you hear and what's actually there.",features:["Real-time FFT spectrum analysis","Peak hold with adjustable decay","Multiple display modes and color schemes","VIZIA glassmorphism UI design","Low latency, high refresh rate"],phase:1,status:"coming-soon",metaTitle:"Amp Spot Analyzer - Real-Time Spectrum Analysis",metaDescription:"Professional spectrum analyzer plugin. See what your ears are telling you. Real-time FFT with peak hold.",ogImage:"/images/og/analyzer.png"},{slug:"ms-processor",title:"Amp Spot M/S",tagline:"Master your stereo field like a pro.",description:"Unlock the power of mid/side processing and transform your mixes. Separate the center information from the stereo width to surgically EQ, compress, and process each independently. Perfect for adding presence to vocals or widening pads.",features:["Independent Mid and Side channel processing","Width control for stereo expansion/narrowing","Mono compatibility monitoring","Phase correlation metering","Swap M/S mode for creative effects"],phase:1,status:"coming-soon",metaTitle:"Amp Spot M/S - Mid/Side Stereo Processor",metaDescription:"Professional mid/side processor plugin. Master your stereo field like a pro. Separate and process mid and side independently.",ogImage:"/images/og/ms-processor.png"}];var n=e.i(85022),l=e.i(75257);let d=l.forwardRef(function({title:e,titleId:t,...s},o){return l.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20",fill:"currentColor","aria-hidden":"true","data-slot":"icon",ref:o,"aria-labelledby":t},s),e?l.createElement("title",{id:t},e):null,l.createElement("path",{d:"M3 4a2 2 0 0 0-2 2v1.161l8.441 4.221a1.25 1.25 0 0 0 1.118 0L19 7.162V6a2 2 0 0 0-2-2H3Z"}),l.createElement("path",{d:"m19 8.839-7.77 3.885a2.75 2.75 0 0 1-2.46 0L1 8.839V14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.839Z"}))}),c=["Professional-grade sound without studio prices","Intuitive interfaces that get out of your way","CPU-efficient for smooth workflow","Built by producers, for producers"],u=[{title:"How to Use EQ to Fix Muddy Mixes",duration:"12:34"},{title:"Compression Masterclass for Beginners",duration:"18:22"},{title:"Amp Spot EQ Plugin - Full Walkthrough",duration:"15:45"}];function m(){let[e,m]=(0,l.useState)(""),[h,p]=(0,l.useState)(!1),g=r.filter(e=>1===e.phase),x=r.filter(e=>2===e.phase);return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("section",{className:"relative overflow-hidden bg-gradient-to-br from-orange-600 via-orange-700 to-red-800 py-24 sm:py-32",children:[(0,t.jsx)("div",{className:"absolute inset-0 opacity-10",children:(0,t.jsx)(a.AudioBars,{count:40,minHeight:30,maxHeight:50,minOpacity:.2,maxOpacity:.5})}),(0,t.jsx)("div",{className:"relative mx-auto max-w-7xl px-6 lg:px-8",children:(0,t.jsxs)("div",{className:"mx-auto max-w-3xl text-center",children:[(0,t.jsxs)("h1",{className:"text-4xl font-bold tracking-tight text-white sm:text-6xl lg:text-7xl",children:["Plugins That ",(0,t.jsx)("span",{className:"text-orange-200",children:"Punch Above Their Weight"})]}),(0,t.jsx)("p",{className:"mt-6 text-lg leading-8 text-orange-100 sm:text-xl",children:"Pro-quality audio tools that won't make your wallet cry. From EQ and compression to saturation and analysis, get studio-quality tools without the studio price tag."}),(0,t.jsxs)("div",{className:"mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row sm:gap-x-6",children:[(0,t.jsx)(s.default,{href:"/plugins",className:"rounded-full bg-white px-8 py-4 text-lg font-semibold text-orange-600 shadow-lg transition-all hover:bg-orange-50 hover:shadow-xl",children:"Explore Plugins"}),(0,t.jsxs)(s.default,{href:"/youtube",className:"text-lg font-semibold leading-6 text-white transition-colors hover:text-orange-200",children:["Watch Tutorials ",(0,t.jsx)("span",{"aria-hidden":"true",children:"→"})]})]})]})})]}),(0,t.jsx)("section",{className:"py-24 bg-slate-950/50",children:(0,t.jsxs)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:[(0,t.jsxs)("div",{className:"mx-auto max-w-3xl text-center mb-16",children:[(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white sm:text-4xl",children:"What is Amp Spot?"}),(0,t.jsx)("p",{className:"mt-4 text-lg text-gray-400",children:"We're a team of passionate audio engineers and producers building tools we actually want to use."})]}),(0,t.jsxs)("div",{className:"grid gap-12 lg:grid-cols-2",children:[(0,t.jsxs)("div",{className:"space-y-6",children:[(0,t.jsx)("p",{className:"text-lg text-gray-300 leading-relaxed",children:"Amp Spot was born from a simple frustration: great sounding plugins shouldn't cost a fortune. We believe every producer deserves access to professional-quality tools, whether you're working in a bedroom studio or a world-class facility."}),(0,t.jsx)("p",{className:"text-lg text-gray-300 leading-relaxed",children:"Our plugins are designed with one goal in mind: help you make better music, faster. No complicated workflows, no endless tweaking—just great sound that gets out of your way and lets you be creative."})]}),(0,t.jsx)("div",{className:"space-y-4",children:c.map(e=>(0,t.jsxs)("div",{className:"flex items-start gap-3",children:[(0,t.jsx)("div",{className:"flex-shrink-0 mt-0.5",children:(0,t.jsx)(n.CheckIcon,{className:"h-5 w-5 text-orange-500","aria-hidden":"true"})}),(0,t.jsx)("span",{className:"text-lg text-gray-300",children:e})]},e))})]})]})}),(0,t.jsx)("section",{className:"py-24",children:(0,t.jsx)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:(0,t.jsx)(o.PluginGrid,{plugins:g,title:"Our Plugin Suite",subtitle:"Professional audio tools designed for modern music production"})})}),x.length>0&&(0,t.jsx)("section",{className:"py-24 bg-slate-950/50",children:(0,t.jsx)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:(0,t.jsx)(o.PluginGrid,{plugins:x,title:"Coming Soon",subtitle:"More powerful tools on the way"})})}),(0,t.jsx)(i.LatestBlog,{}),(0,t.jsx)("section",{className:"py-24 bg-gradient-to-br from-slate-900 to-slate-950",children:(0,t.jsxs)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8",children:[(0,t.jsxs)("div",{className:"max-w-xl mb-12",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3 mb-6",children:[(0,t.jsx)("div",{className:"rounded-full bg-red-500/20 p-2",children:(0,t.jsx)("svg",{className:"h-5 w-5 text-red-400",fill:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{fillRule:"evenodd",d:"M19.812 5.418c.861.23 1.538.907 1.768 1.768C21.998 8.746 22 12 22 12s0 3.255-.418 4.814a2.504 2.504 0 0 1-1.768 1.768c-1.56.419-7.814.419-7.814.419s-6.255 0-7.814-.419a2.505 2.505 0 0 1-1.768-1.768C2 15.255 2 12 2 12s0-3.255.417-4.814a2.507 2.507 0 0 1 1.768-1.768C5.744 5 11.998 5 11.998 5s6.255 0 7.814.418ZM15.194 12 10 15V9l5.194 3Z",clipRule:"evenodd"})})}),(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white",children:"Latest on YouTube"})]}),(0,t.jsx)("p",{className:"text-lg text-gray-400",children:"Watch tutorials, walkthroughs, and mixing tips on our YouTube channel"})]}),(0,t.jsx)("ul",{className:"space-y-4",children:u.map((e,s)=>(0,t.jsx)("li",{children:(0,t.jsxs)("a",{href:"https://youtube.com/@ampspot",target:"_blank",rel:"noopener noreferrer",className:"group block rounded-2xl bg-slate-800/50 border border-slate-700/50 p-6 backdrop-blur-sm hover:border-red-500/50 transition-all",children:[(0,t.jsx)("p",{className:"text-white font-medium group-hover:text-red-400 transition-colors",children:e.title}),(0,t.jsx)("span",{className:"text-sm text-gray-500 mt-2 inline-block",children:e.duration})]})},s))}),(0,t.jsx)("div",{className:"mt-6",children:(0,t.jsxs)("a",{href:"https://youtube.com/@ampspot",target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center text-sm font-semibold text-red-400 hover:text-red-300",children:["Watch on YouTube",(0,t.jsx)("svg",{className:"ml-2 h-4 w-4",fill:"none",viewBox:"0 0 24 24",strokeWidth:"2",stroke:"currentColor",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"})})]})})]})}),(0,t.jsxs)("section",{className:"py-24 bg-gradient-to-br from-orange-600 to-red-800 relative overflow-hidden",children:[(0,t.jsx)("div",{className:"absolute inset-0 opacity-10",children:(0,t.jsx)(a.AudioBars,{count:30,minHeight:30,maxHeight:50,minOpacity:.2,maxOpacity:.5})}),(0,t.jsxs)("div",{className:"relative mx-auto max-w-4xl px-6 lg:px-8 text-center",children:[(0,t.jsxs)("div",{className:"inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 mb-6 backdrop-blur-sm",children:[(0,t.jsx)(d,{className:"h-5 w-5 text-orange-200"}),(0,t.jsx)("span",{className:"text-sm font-medium text-orange-200",children:"Newsletter"})]}),(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white sm:text-4xl",children:"Get Production Tips Delivered"}),(0,t.jsx)("p",{className:"mt-4 text-lg text-orange-100",children:"Join our newsletter for mixing tips, plugin updates, and exclusive content. No spam, just value."}),(0,t.jsxs)("form",{onSubmit:t=>{t.preventDefault(),e&&(p(!0),m(""))},className:"mt-8 sm:flex sm:max-w-lg sm:mx-auto",children:[(0,t.jsx)("input",{type:"email",value:e,onChange:e=>m(e.target.value),placeholder:"Enter your email",required:!0,className:"w-full rounded-full border-0 px-6 py-4 text-gray-900 shadow-sm ring-1 ring-inset ring-orange-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-white sm:text-sm sm:leading-6"}),(0,t.jsx)("button",{type:"submit",className:"mt-4 sm:mt-0 sm:ml-4 flex-none rounded-full bg-white px-6 py-4 text-sm font-semibold text-orange-600 shadow-sm hover:bg-orange-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white transition-colors",children:"Subscribe"})]}),h&&(0,t.jsx)("p",{className:"mt-4 text-sm text-green-200",children:"✓ Thanks for subscribing! Check your inbox for confirmation."}),(0,t.jsx)("p",{className:"mt-4 text-xs text-orange-200",children:"By subscribing, you agree to our Privacy Policy. Unsubscribe anytime."})]})]}),(0,t.jsx)("section",{className:"bg-gradient-to-br from-slate-900 to-slate-950 py-24",children:(0,t.jsxs)("div",{className:"mx-auto max-w-7xl px-6 lg:px-8 text-center",children:[(0,t.jsx)("h2",{className:"text-3xl font-bold tracking-tight text-white sm:text-4xl",children:"Ready to level up your mixes?"}),(0,t.jsx)("p",{className:"mt-4 text-lg text-gray-300",children:"Try all our plugins free for 14 days. No credit card required."}),(0,t.jsx)("div",{className:"mt-10",children:(0,t.jsx)(s.default,{href:"/download",className:"rounded-full bg-orange-600 px-8 py-4 text-lg font-semibold text-white shadow-lg shadow-orange-500/30 transition-all hover:bg-orange-500 hover:shadow-xl hover:shadow-orange-500/40",children:"Start Your Free Trial"})})]})})]})}e.s(["default",()=>m],24028)}]);